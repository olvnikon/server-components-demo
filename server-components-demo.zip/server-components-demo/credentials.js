module.exports = {
  host: process.env.DB_HOST || 'localhost',
  database: 'notesapi',
  user: 'notesadmin',
  password: 'password',
  port: '5432',
};
